<?php

//a class for dealing with a object comment saving, reading and deleting it from the database
class WorkModel
{
    public $id;
    public $name;
    public $starting_date;
    public $ending_date;
    public $status;

    public function __construct($id, $name, $starting_date, $ending_date, $status)
    {
        // public function __construct($id, $name) {
        $this->id = $id;
        $this->name = $name;
        $this->starting_date = $starting_date;
        $this->ending_date = $ending_date;
        $this->status = $status;
    }

    public static function get($work_id)
    {
        $list = [];
        $db = Db::getInstance();
        if ($result = mysqli_query($db, "SELECT id, name, starting_date, ending_date, status FROM work where id = $work_id")) {
            if ($row = mysqli_fetch_assoc($result)) {
                $list = new WorkModel($row['id'], $row['name'], $row['starting_date'], $row['ending_date'], $row['status']);
            }
        }
        return $list;
    }

    public static function all()
    {
        //list of al comments
        $list = [];
        $db = Db::getInstance();
        $result = mysqli_query($db, 'SELECT id, name, starting_date, ending_date, status FROM work');
        // print_r($result);

        while ($row = mysqli_fetch_assoc($result)) {
            $list[] = new WorkModel($row['id'], $row['name'], $row['starting_date'], $row['ending_date'], $row['status']);
            #$list[] = new WorkModel($row['id'], $row['name']);
        }

        return $list;
    }
    
    public static function getTop3()
    {
        //list of al comments
        $list = [];
        $db = Db::getInstance();
        $result = mysqli_query($db, 'SELECT id, name, starting_date, ending_date, status FROM work ORDER BY (id) DESC limit 3');
        // print_r($result);

        while ($row = mysqli_fetch_assoc($result)) {
            $list[] = new WorkModel($row['id'], $row['name'], $row['starting_date'], $row['ending_date'], $row['status']);
            #$list[] = new WorkModel($row['id'], $row['name']);
        }

        return $list;
    }

    public static function search($start,$end)
    {
        //list of al comments
        $list = [];
        $db = Db::getInstance();
        $query = "SELECT id, name, starting_date, ending_date, status FROM work WHERE NOT ((ending_date < '$start') OR (starting_date > '$end'))";

        $result = mysqli_query($db, $query);
        // print_r($result);
        // print_r($result);
        // print_r($f);
        
        while ($row = mysqli_fetch_assoc($result)) {
            // $work_in_calendar = array();
            $work_in_calendar = null;
            $work_in_calendar->id = $row['id'];
            $work_in_calendar->text = $row['name'];
            $work_in_calendar->start = $row['starting_date'];
            $work_in_calendar->end = $row['ending_date'];
            $work_in_calendar->status = $row['status'];
            
            $list[] = $work_in_calendar;
            // $list[] = new WorkModel($row['id'], $row['name'], $row['starting_date'], $row['ending_date'], $row['status']);
            #$list[] = new WorkModel($row['id'], $row['name']);
        }

        return $list;
    }



    public static function delete($id)
    {
        $db = Db::getInstance();
        $result = mysqli_query($db, "delete from work where id='$id'");
        return true;
    }

    public static function add($name, $starting_date, $ending_date, $status)
    {

        $db = Db::getInstance();
        
        $result = mysqli_query($db, "Insert into work (name, starting_date, ending_date, status) Values ('$name','$starting_date', '$ending_date', '$status' )");
        $id = mysqli_insert_id($db);
       
        return new WorkModel($id, $name, $starting_date, $ending_date, $status);
    }
}
