Simple-MVC-without-a-framework

PHP + JS(JQUERY + AJAX) + CSS + HTML + RESTful + MySQL -> XAMP/UwAmp + PhpStorm

This is a great simple MVC skeleton in PHP that implements all the basic features of web programming. 

I couldn't find a great MVC skeleton without all the functions implemented so I uploaded mine.

The only file that can be confusing is routes.php that instead of having several different routes, it has just one that will get the name of the controller and the name of the action(function), therefore CRUD isn't effective.

P.S - Don't forget to connect to your local database when running, just in case.
Any questions, send me a message.

