﻿<!-- a simple view returning json data -->
<?php
include "view/header.php";
echo "<h3 style=\"text-align: center;\">Work deleted</h3>";
json_encode($work);
include "view/footer.php";
?>