
    <div class="row">
        <div class="col">
            <ul class="list-group">
                <?php foreach ($works as $work) {?>
                    <li class="list-group-item">
                        <strong>
                            <?php echo $work->name; ?>
                        </strong>
                        <l> | <a href="index.php?controller=comment&action=allFromUser&id=<?php echo $work->id; ?>">
                                View Comments
                            </a> | </l>
                        <a href="index.php?controller=work&action=delete&id=<?php echo $work->id; ?>" onclick="deleteWorkAJAX(this)">
                            <?php echo "Delete"; ?>
                        </a>
                    </li>
                <?php }?>
            </ul>
        </div>
    </div>
