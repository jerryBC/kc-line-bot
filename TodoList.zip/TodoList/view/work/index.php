
<!-- a simple view, outputing all the comments -->
<?php include "view/header.php"?>
<div class="container" style="background-color: indianred; padding-bottom: 2%; padding-top: 1%;">
    <h5 style="text-align: center;color: whitesmoke;">Add a new Work</h5>
    <div class="row">
        <div class="col">
            <form id="workForm" action="index.php?controller=work&action=add" method="POST">
                <table>
                    <tr>
                        <td colspan="2">
                            <input name = "name" type="text" class="form-control" placeholder="Work Name" aria-label="Name" aria-describedby="basic-addon1" required>
                        </td>
                    </tr>
                    <tr>
                        <td><input name = "starting_date" type="text" class="form-control" placeholder="Starting Date" aria-label="starting_date" aria-describedby="basic-addon1" required readonly='true' id = "datepicker-starting-date"></td>
                        <td><input name = "ending_date" type="text" class="form-control" placeholder="Ending Date" aria-label="ending_date" aria-describedby="basic-addon1" required readonly='true' id = "datepicker-ending-date"></td>
                    </tr>
                    <tr>
                        <td>
                            <!-- <input name = "status" type="text" class="form-control" placeholder="Status" aria-label="status" aria-describedby="basic-addon1" required> -->
                            <select name="status" class="form-control">
                                <option value="Planning">Planning</option>
                                <option value="Doing">Doing</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </td>
                    </tr>
                </table>
                <input id="workBtn" class="btn" type="submit" value="Submit">
            </form>
        </div>
    </div>
</div>
<br>
<h3 style="text-align: center;">My Works</h3>
<br style="padding-bottom: 20%">
<div id="works" class="container FixedHeightContainer">
    <div class="row Content">
        <div class="col">
            <style> 
                    table.list_work {
                        width:100%;
                    }
                    .list_work td, th {
                        border: 1px solid black;
                        padding: 5px;
                        /* width:100%; */
                    }
                    table.list_work td:first-child{
                        width:50px!important;
                    }

                    .list_work th {
                        text-align: center;
                    }
                    table.list_work thead th:first-child,
                    {
                        width:30px!important;
                    }

            </style>
            <table class="list_work">
                <thead>
                    <th>ID</th>
                    <th>Work Name</th>
                    <th>Starting Date</th>
                    <th>Ending Date</th>
                    <th>Status</th>
                    <th></th>
                </thead>    
           
            <!-- <ul class="list-group"> -->
                <tbody>
                <?php foreach ($works as $work) {?>
                    <!-- <li class="list-group-item"> -->
                        <tr>
                            <td><?php echo $work->id; ?></td>
                            <td><?php echo $work->name; ?></td>
                            <td><?php echo $work->starting_date; ?></td>
                            <td><?php echo $work->ending_date; ?></td>
                            <td><?php echo $work->status; ?></td>
                            <td><a class="deleteWork" href="index.php?controller=work&action=delete&id=<?php echo $work->id; ?>" onclick="deleteWorkAJAX(this)">
                            <?php echo "Delete"; ?>
                        </a></td>
                       
                    </tr>
                    <!-- </li> -->
                <?php }?>
                </tbody>
                </table>
                <a href="http://localhost/TodoList/index.html">show more in calendar</a>
            <!-- </ul> -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){

        $("#workForm").submit(function(e) {

            var url = "/TodoList/index.php?controller=work&action=add"; // the script where you handle the form input.

            $.ajax({
                type: "POST",
                url: url,
                data: $("#workForm").serialize(), // serializes the form's elements.
                success: function(data)
                {
                    // alert(data); // show response from the php script.
                    // showWorks();
                }
            });
            e.preventDefault(); // avoid to execute the actual submit of the form.
            showWorks();
        });



    });


         $(function() {
            $( "#datepicker-starting-date" ).datepicker({ dateFormat: 'yy-mm-dd' });
            $( "#datepicker-ending-date" ).datepicker({ dateFormat: 'yy-mm-dd' });

         });


    function showWorks() {
        $.get("http://localhost/TodoList/index.php?controller=work&action=showAll", function (data) {
            $("#works").html(data);
        });
    }

    function deleteWorkAJAX($event) {
        $.ajax({
                url: $event,
                success: function(response) {
                    //alert(response);
                }
            });
        event.preventDefault();
        showWorks();
    }


</script>

