
<!-- Footer -->
<footer class="page-footer font-small" style="
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: dodgerblue;
        color: white;
        text-align: center;">

    <!-- Footer Links -->
    <div class="container-fluid text-center text-md-left">

        <!-- Grid row -->
        <div class="row">
            <!-- Grid column -->
            <div class="col">
                <!-- Content -->
                <br>
                <h5 class="text-uppercase" style="text-align: center">F.E.R.I - University of Maribor</h5>
                <p style="text-align: center">Web programming - David Moniz</p>
            </div>
            <!-- Grid column -->
        </div>
        <!-- Grid row -->
    </div>
</footer>
<!-- Footer -->
</body>
</html>
