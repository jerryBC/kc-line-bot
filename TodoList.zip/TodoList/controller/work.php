<?php

class work
{
//three simple actions

//return all the comments
    public function all()
    {
        //use the model to get all the comments from the database
        $works = WorkModel::getTop3();
        require_once "view/work/index.php";
    }

    //AJAX
    public function showAll()
    {
        $works = WorkModel::getTop3();
        require_once "view/work/showWorks.php";
    }

//delete a comment
    public function delete()
    {
        //read the id passed over query string
        if (isset($_GET["id"])) {
            $id = $_GET["id"];
        }

//execute the delete command on the model
        $work = WorkModel::delete($id);
//return a simple view of confirming the deletion
        require_once "view/work/delete.php";
    }

    public function add()
    {
        //read the data send over post method
        if (isset($_POST["name"])) {

            $name = $_POST["name"];
            $starting_date = $_POST["starting_date"];
            ($starting_date);
            $ending_date = $_POST["ending_date"];
            ($ending_date);
            $status = $_POST["status"];
            ($status);
            //add a new comment using the model
            $work = WorkModel::add($name, $starting_date, $ending_date, $status);
            //return the conformation of succesful insertion
            require_once "view/work/add.php";
            //  require_once("view/work/showWorks.php");
        }
    }

    public function addCalendar()
    {
        $json = file_get_contents('php://input');
        $_POST = json_decode($json);
        
        
        //read the data send over post method
        if (isset($_POST->text)) {

            $name = $_POST->text;
            $starting_date = $_POST->start;
            
            $ending_date = $_POST->end;
            
            $status = $_POST->status;
            
            //add a new comment using the model
            // print_r($starting_date);
            // print_r($name);
            // print_r($ending_date);
            // print_r($status);
            $work = WorkModel::add($name, $starting_date, $ending_date, $status);
            header('Content-Type: application/json');
            echo json_encode($work);
            // print_r('yaaaaaaa');
            //return the conformation of succesful insertion
            // require_once "view/work/add.php";
            //  require_once("view/work/showWorks.php");
           
        }
    }

    public function loadWorkCalendar()
    {
        $start = $_GET["start"];
        $end = $_GET["end"];
        // print_r($start);
        // print_r($end);
        $works = WorkModel::search($start, $end);
            header('Content-Type: application/json');
            echo json_encode($works);
            // print_r('yaaaaaaa');
            //return the conformation of succesful insertion
            // require_once "view/work/add.php";
            //  require_once("view/work/showWorks.php");
           
        
    }
}
